function telaVenceu(){
  background(imgvenceu)
  
  push()
  opcaoBotaoCircular(CxvoltarMenu, CyvoltarMenu,d2,raio)
  opcaoBotaoCircular(Cxagain, Cyagain,d3,raio)
  pop()
  
}