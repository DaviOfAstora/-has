
function telaGameOver(){
  background(imggameover)
  push()
  opcaoBotaoCircular(CxvoltarMenu, CyvoltarMenu,d2,raio)
  opcaoBotaoCircular(Cxagain, Cyagain,d3,raio)
  pop()
  
}